import { Product } from '../product/product.model';

export class CurrentCartService{
    currentItems:Product[] =[];

    addItemToCart(newProduct:Product){        
        this.currentItems.push(newProduct);
        console.log(this.currentItems);
    }
    removeItemFromCart(theId:number){  
        var index = this.currentItems.findIndex(i=>i.id == theId)      
        this.currentItems.splice(index,1);
        console.log(this.currentItems);

    }
}