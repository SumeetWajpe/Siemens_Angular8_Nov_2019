import { Component, OnInit } from '@angular/core';
import { CurrentCartService } from './currentcart.service';

@Component({
  selector: 'app-currentcart',
  templateUrl: './currentcart.component.html',
  styleUrls: ['./currentcart.component.css']
})
export class CurrentcartComponent implements OnInit {

  constructor(public currCartServObj:CurrentCartService) { }

  ngOnInit() {
  }

}
