import {ValidatorFn,AbstractControl} from '@angular/forms';

// validator functions

export function restrictProductTitleValidator(productTitleRegex:RegExp):ValidatorFn{
        return (control:AbstractControl):{[key:string]:any} | null =>{
                var restrictedTitleName = productTitleRegex.test(control.value);
                return restrictedTitleName ? {'restrictedName':{value:control.value}} : null;
        }
}