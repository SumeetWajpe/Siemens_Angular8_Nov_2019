import { Component, OnInit } from '@angular/core';
import { FormGroup, FormControl, Validators } from '@angular/forms';
import { Product } from '../product/product.model';
import { ProductService } from '../product/product.service';
import { restrictProductTitleValidator } from './customValidation';

@Component({
  selector: 'app-model-driven',
  templateUrl: './model-driven.component.html',
  styleUrls: ['./model-driven.component.css']
})
export class ModelDrivenComponent implements OnInit {

  productForm:FormGroup;
  newProduct:Product = new Product();
  constructor(public prodServObj:ProductService) { }

  ngOnInit() {
    this.productForm = new FormGroup({
        'title':new FormControl(this.newProduct.title,
          [Validators.required,
          Validators.minLength(5),
        restrictProductTitleValidator(/laptop/i)
        ]),
          'price':new FormControl(this.newProduct.price),
          'rating':new FormControl(this.newProduct.rating),
          'quantity':new FormControl(this.newProduct.quantity),
          'likes':new FormControl(this.newProduct.likes),
          'ImageUrl':new FormControl(this.newProduct.ImageUrl),
        
    });// eof form group
  }

  get f(){
      return this.productForm.controls;
  }

  AddNewProduct(){  
    if(this.productForm.valid){
      this.prodServObj.addNewProduct(
        this.productForm.value);
      this.newProduct = new Product();
      // form reset !
      this.productForm.reset();
    }
  
  }
    

}
