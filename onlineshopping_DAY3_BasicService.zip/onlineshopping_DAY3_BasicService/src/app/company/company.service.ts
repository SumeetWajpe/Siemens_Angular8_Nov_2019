export class CompanyService{
    listofcompanies:string[] = ["IBM","Microsoft","Siemens","Accenture"];

    getAllCompanies():string[]{
        return this.listofcompanies;
    }
}