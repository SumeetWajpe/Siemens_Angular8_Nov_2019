import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import {FormsModule} from '@angular/forms';

import { AppComponent } from './app.component';
import {ProductComponent} from './product/product.component';
import { ShoppingCartComponent } from './shopping-cart/shopping-cart.component';
import {QuantityPipe} from './quantity.pipe';
import { CompanyComponent } from './company/company.component';
@NgModule({
  declarations: [
    AppComponent,ProductComponent, 
    ShoppingCartComponent,QuantityPipe, CompanyComponent
  ],
  imports: [
    BrowserModule,FormsModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
