import { Component, OnInit } from '@angular/core';
import { Product } from '../product/product.model';
import { ProductService } from '../product/product.service';
import { ProductAPIService } from '../product/productservicewithhttp';

@Component({
  selector: 'app-shopping-cart',
  templateUrl: './shopping-cart.component.html',
  styleUrls: ['./shopping-cart.component.css']
})
export class ShoppingCartComponent implements OnInit {
heading="Online Shopping";
companyname:string="";
productName:string ="";
products: Product[] = [];


// constructor(public prodServObj:ProductAPIService){
// }

constructor(public prodServObj:ProductService){
}

ChangeHeading(){
  this.heading = "Flipkart !";
}
ChangeHandlerOnTextChange(evt){
  this.heading =evt.target.value;
}

  // ngOnInit(){
  //   let aPromise = this.prodServObj.GetAllProducts();
  //   aPromise.then(
  //     (response)=>{  
  //       this.products = response;      
  //     },
  //     (err)=>console.log(err)
  //   )

  ngOnInit(){
      this.products = this.prodServObj.getAllProducts();
  }


}
