import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class UserService {
  isUserLoggedIn:boolean;
  constructor() {
    this.isUserLoggedIn = false;
   }

   getUserLoggedIn(){
     // AJAX request !
     return this.isUserLoggedIn;
   }

   setUserLoggedIn(){
     this.isUserLoggedIn = true;
   }
}
