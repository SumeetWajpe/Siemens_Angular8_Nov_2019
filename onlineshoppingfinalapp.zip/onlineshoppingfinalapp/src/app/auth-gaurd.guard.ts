import { Injectable } from '@angular/core';
import { CanActivate, ActivatedRouteSnapshot, RouterStateSnapshot, UrlTree, Router } from '@angular/router';
import { Observable } from 'rxjs';
import { UserService } from './user.service';

@Injectable({
  providedIn: 'root'
})
export class AuthGaurd implements CanActivate {
  constructor(public userServObj:UserService,
    public router:Router){}
  canActivate(
    next: ActivatedRouteSnapshot,
    state: RouterStateSnapshot): Observable<boolean | UrlTree> | Promise<boolean | UrlTree> | boolean | UrlTree {
    // condition to be true ??
    // if user is logged in ??
    if(!this.userServObj.getUserLoggedIn()){
      this.router.navigate(["/"]);// navigate to login
    }
    return this.userServObj.getUserLoggedIn(); // return true !
  }
  
}
