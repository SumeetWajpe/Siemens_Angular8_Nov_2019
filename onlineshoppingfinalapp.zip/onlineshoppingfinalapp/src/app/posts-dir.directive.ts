import { Directive, ElementRef, Input, HostListener } from '@angular/core';

@Directive({
  selector: '[highlight]'
})
export class PostsDirDirective {

  constructor(public refElement:ElementRef) { }

  @Input('color') passedColor:string="yellow";

  ngOnInit(){
    this.refElement.nativeElement.style.backgroundColor
     = this.passedColor;
    this.refElement.nativeElement.style.borderRadius = "2px";
    this.refElement.nativeElement.style.margin = "10px";
    this.refElement.nativeElement.style.padding = "10px";
    this.refElement.nativeElement.style.border = "2px solid red";
  // this.refElement.nativeElement.innerHTML += "Changed !";
  }

  @HostListener('mouseenter') On_Mouse_Enter(){
    this.refElement.nativeElement.style.backgroundColor
    = "lightgreen";
    this.refElement.nativeElement.style.transform
    = "scale(1.1)";
    this.refElement.nativeElement.style.cursor = "pointer";
  }

  @HostListener('mouseleave') On_Mouse_Leave(){
    this.refElement.nativeElement.style.backgroundColor
    = this.passedColor;
    this.refElement.nativeElement.style.transform
    = "scale(1)";
  }

}
