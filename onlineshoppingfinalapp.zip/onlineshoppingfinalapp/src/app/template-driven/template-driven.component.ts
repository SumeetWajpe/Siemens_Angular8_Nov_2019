import { Component, OnInit } from '@angular/core';
import { ProductService } from '../product/product.service';
import { Product } from '../product/product.model';

@Component({
  selector: 'app-template-driven',
  templateUrl: './template-driven.component.html',
  styleUrls: ['./template-driven.component.css']
})
export class TemplateDrivenComponent implements OnInit {
  newProduct:Product = new Product();

  constructor(public prodServObj:ProductService) { }

  ngOnInit() {
  }

  AddNewProduct(theForm){
    if(theForm.valid){
      this.prodServObj.addNewProduct(this.newProduct)
      this.newProduct = new Product();
      // form reset !
      theForm.reset();
    }
    
   }
   

}
