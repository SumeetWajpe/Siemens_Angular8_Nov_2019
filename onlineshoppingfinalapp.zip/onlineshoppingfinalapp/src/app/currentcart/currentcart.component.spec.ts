import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { CurrentcartComponent } from './currentcart.component';

describe('CurrentcartComponent', () => {
  let component: CurrentcartComponent;
  let fixture: ComponentFixture<CurrentcartComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ CurrentcartComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CurrentcartComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
