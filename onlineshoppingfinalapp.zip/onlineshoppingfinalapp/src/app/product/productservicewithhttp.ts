import { Product } from './product.model';
import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';

@Injectable({
    providedIn:'root'
})
export class ProductAPIService {
    products:Product[]=[];
   constructor(private httpClientObj:HttpClient){
   }

    GetAllProducts() {
        return this.httpClientObj.get<Product[]>('https://api.myjson.com/bins/lsyqu').toPromise()
    }   
    
}