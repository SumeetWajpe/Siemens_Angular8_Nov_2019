import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { PostsService } from '../posts/posts.service';
import { Post } from '../posts/post.model';

@Component({
  selector: 'app-post-details',
  templateUrl: './post-details.component.html',
  styleUrls: ['./post-details.component.css']
})
export class PostDetailsComponent implements OnInit {
 thePostId:number;
 thePost:Post = new Post();
  constructor(public currRoute:ActivatedRoute,
    public postServObj:PostsService) { }

  ngOnInit() {
    // read the params !
    this.currRoute.params.subscribe(
      p=>{
        this.thePostId = p.postid; 
        // var thePromiseOfPosts = this.postServObj.getAllPosts();
        // thePromiseOfPosts.then(
        //   (response)=>{
        //       this.thePost = response.find(post=> post.id == this.thePostId)
        //   }
        // )
        // OR
        this.thePost = this.postServObj.allPosts.find(
          post=> post.id == this.thePostId);
      }
    )
  }

}
