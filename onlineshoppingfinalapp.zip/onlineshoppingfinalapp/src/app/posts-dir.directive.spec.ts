import { PostsDirDirective } from './posts-dir.directive';

describe('PostsDirDirective', () => {
  it('should create an instance', () => {
    const directive = new PostsDirDirective();
    expect(directive).toBeTruthy();
  });
});
