import { Component, OnInit, Input, OnChanges } from '@angular/core';

@Component({
  selector: 'app-message',
  templateUrl: './message.component.html',
  styleUrls: ['./message.component.css']
})
export class MessageComponent implements OnInit,OnChanges {
  @Input() message:string="";
  constructor() {
    console.log('Within Constructor !')
    console.log(this.message);
   }

  ngOnInit() {
    console.log('Within ngOnInit !');
    console.log(this.message);
  }

  ngOnChanges(){
    console.log('Within ngOnChanges !');
    console.log(this.message);
  }

}
