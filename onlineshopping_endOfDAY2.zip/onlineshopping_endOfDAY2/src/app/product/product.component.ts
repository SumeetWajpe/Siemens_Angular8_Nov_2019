import{Component, Input} from '@angular/core';// node_modules
import { Product } from './product.model';

@Component({
    selector:'product',
    templateUrl:'./product.template.html',
    styleUrls:['./product.style.css']
})
export class ProductComponent{
  @Input()  productdetails:Product={};
  isHighlighted:boolean=false;
  isFree:boolean=false;

  ClickHandler(){
      // model update
      this.productdetails.likes++;
  }
}