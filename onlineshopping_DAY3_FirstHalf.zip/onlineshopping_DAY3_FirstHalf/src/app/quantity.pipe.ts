import { Pipe,PipeTransform } from '@angular/core';

@Pipe({
    name:'qty'
})
export class QuantityPipe implements PipeTransform{
            transform(theValue:number,theArgs:string){
                if(theValue == 0){
                    return 'Out Of Stock !';
                }
                    return theValue + " " + theArgs;
            }
}