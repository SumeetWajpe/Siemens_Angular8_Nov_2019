import { Component, OnInit } from '@angular/core';
import { Product } from '../product/product.model';
import { ProductService } from '../product/product.service';

@Component({
  selector: 'app-shopping-cart',
  templateUrl: './shopping-cart.component.html',
  styleUrls: ['./shopping-cart.component.css']
})
export class ShoppingCartComponent {
heading="Online Shopping";
companyname:string="";

constructor(public prodServObj:ProductService){
    this.products =  this.prodServObj.getAllProducts();
}

ChangeHeading(){
  this.heading = "Flipkart !";
}
ChangeHandlerOnTextChange(evt){
  this.heading =evt.target.value;
}
  products: Product[] = [];



}
