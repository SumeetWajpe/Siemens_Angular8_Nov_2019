import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';

@Injectable()
export class PostsService{
    constructor(public httpServObj:HttpClient){

    }
    getAllPosts(){
        // make an ajax request
        this.httpServObj.get('https://jsonplaceholder.typicode.com/posts').subscribe(function(response){
            return (response);
        })
    }
}