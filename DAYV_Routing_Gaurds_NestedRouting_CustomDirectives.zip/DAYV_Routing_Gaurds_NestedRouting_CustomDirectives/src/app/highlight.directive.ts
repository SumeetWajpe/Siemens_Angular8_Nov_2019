import { Directive, ElementRef, Input, HostListener } from '@angular/core';

@Directive({
  selector: '[appHighlight]'
})
export class HighlightDirective {
  @Input() bkColor:string ="lightgreen";
  constructor(public elemRef:ElementRef) { }
  ngOnInit(){
    this.elemRef.nativeElement.style.border = "2px solid red";
    this.elemRef.nativeElement.style.borderRadius = "5px";
    this.elemRef.nativeElement.style.margin = "5px";
    this.elemRef.nativeElement.style.padding = "5px";
    this.elemRef.nativeElement.style.background = this.bkColor;
  }

  @HostListener('mouseenter')
  CalledOnMouseEnter(){   
    this.elemRef.nativeElement.style.background = "orange";
    this.elemRef.nativeElement.style.cursor = "pointer";

  }
  @HostListener('mouseleave')
  CalledOnMouseLeave(){
    this.elemRef.nativeElement.style.background = this.bkColor;
  }

}
