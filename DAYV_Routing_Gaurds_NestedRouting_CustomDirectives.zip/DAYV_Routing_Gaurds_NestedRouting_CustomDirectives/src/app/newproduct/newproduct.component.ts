import { Component, OnInit } from '@angular/core';
import { ProductModel } from '../product.model';
import { ProductService } from '../product.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-newproduct',
  templateUrl: './newproduct.component.html',
  styleUrls: ['./newproduct.component.css']
})
export class NewproductComponent implements OnInit {
  newProduct:ProductModel = new ProductModel();
  constructor(public prodServObj:ProductService,
    public router:Router) { }
  ngOnInit() {
  }
  AddNewProduct(theForm){
    // add a new product to products from product service !
    if(theForm.valid){
      this.prodServObj.addAProduct(this.newProduct);
      this.newProduct = new ProductModel();
      theForm.reset();
      // navigate
      this.router.navigate(["/dashboard"]);
    } 
  }

}
