import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import {FormsModule} from '@angular/forms';
import {HttpClientModule} from '@angular/common/http';
import {RouterModule,Routes} from '@angular/router';

import { AppComponent } from './app.component';
import { ShoppingCartComponent } from './shoppingcart.component';
import { ProductComponent } from './product.component';
import { QuantityPipe } from './quantity.pipe';
import { CompanyComponent } from './company/company.component';
import { CompanyService } from './company/company.service';
import { ProductService } from './product.service';
import { CartItemsComponent } from './cart-items/cart-items.component';
import { CartItemsService } from './cart-items/cartitems.service';
import { PostsComponent } from './posts/posts.component';
import { NewproductComponent } from './newproduct/newproduct.component';
import { PostDetailsComponent } from './post-details/post-details.component';
import { DashboardComponent } from './dashboard/dashboard.component';
import { LoginComponent } from './login/login.component';
import { AuthGuard } from './auth.guard';
import { MessageComponent } from './message/message.component';
import { LifeCycleHookComponent } from './life-cycle-hook/life-cycle-hook.component';
import { HighlightDirective } from './highlight.directive';

// const routes:Routes = [
//   {path:'',component:ShoppingCartComponent},
//   {path:'posts',component:PostsComponent},
//   {path:'postdetails/:pid',component:PostDetailsComponent},
//   {path:'newproduct',component:NewproductComponent},
//   {path:'company',component:CompanyComponent},
//   {path:'**',redirectTo:'/'}
// ];

const routes:Routes=[
  {path:'',component:LoginComponent},
  {path:'dashboard',component:DashboardComponent,
    children:[
      {path:'',component:ShoppingCartComponent},
      {path:'posts',component:PostsComponent},
      {path:'postdetails/:pid',component:PostDetailsComponent},
      {path:'newproduct',component:NewproductComponent},
      {path:'company',component:CompanyComponent},
      {path:'lifecycle',component:MessageComponent}
    ],
    //canActivate:[AuthGuard]
  },
  {path:'**',redirectTo:'/'}
];



@NgModule({
  declarations: [
    AppComponent,ShoppingCartComponent,ProductComponent,QuantityPipe, 
    CompanyComponent, CartItemsComponent, PostsComponent, NewproductComponent, PostDetailsComponent, DashboardComponent, LoginComponent, MessageComponent, LifeCycleHookComponent, HighlightDirective
  ],
  imports: [
    BrowserModule,FormsModule,HttpClientModule,RouterModule.forRoot(routes)
  ],
  providers: [CompanyService,ProductService,CartItemsService],
  bootstrap: [AppComponent]
})
export class AppModule { }
