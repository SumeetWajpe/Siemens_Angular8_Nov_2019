import { ProductModel } from './product.model';

export class ProductService{
    listofproducts:ProductModel[] = [
        {title:'LED TV',price:50000,quantity:0,rating:4,imageUrl:'https://images-na.ssl-images-amazon.com/images/I/818yneFa4iL._AC_SL1500_.jpg',likes:100},
        {title:'DSLR',price:100000,quantity:400,rating:3,imageUrl:'https://images-na.ssl-images-amazon.com/images/I/81Po%2BtPr61L._AC_SX450_.jpg',likes:400},
        {title:'Drone',price:120000,quantity:500,rating:4.566,imageUrl:'https://encrypted-tbn0.gstatic.com/images?q=tbn%3AANd9GcSFwGEtst4fvLKIHeeMwkrO5rNbTGEFNvLuy1Frn33kAQfVO7Ah',likes:800},
        {title:'Mobile',price:15000,quantity:700,rating:5,imageUrl:'https://images-na.ssl-images-amazon.com/images/I/61itOh%2BJe8L._AC_SL1024_.jpg',likes:200},
        {title:'Go Pro 7',price:35000,quantity:0,rating:3.554,imageUrl:'https://images-na.ssl-images-amazon.com/images/I/71UAtd5yS5L._AC_SL1500_.jpg',likes:900}
      ];

    getAllProducts():ProductModel[]{
        return this.listofproducts;
    }

    deleteAProduct(productToBeDeleted:string){
        // logic to delete from array   
    let index = this.listofproducts.findIndex(p => p.title == productToBeDeleted);
    this.listofproducts.splice(index,1);
}

addAProduct(productToBeAdded:ProductModel){
    this.listofproducts.push(productToBeAdded);
}

}