export class CompanyService{
    listOfCompanies:string[]=["IBM","Microsoft","Accenture","Google","CAPCO"];

    getAllCompanies():string[]{
        return this.listOfCompanies;
    }

    addACompany(newCompanyToBeadded:string){
        this.listOfCompanies.push(newCompanyToBeadded);
    }
}