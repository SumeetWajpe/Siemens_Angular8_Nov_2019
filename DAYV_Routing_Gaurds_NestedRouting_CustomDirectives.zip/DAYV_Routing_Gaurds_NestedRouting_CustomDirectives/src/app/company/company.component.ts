import { Component, OnInit } from '@angular/core';
import { CompanyService } from './company.service';

@Component({
  selector: 'app-company',
  templateUrl: './company.component.html',
  styleUrls: ['./company.component.css'],
  providers:[CompanyService]
})
export class CompanyComponent  {
  companies:string[]=[];
  newCompany:string="";
  //DI
  constructor(public servObj:CompanyService) {
    this.companies = (this.servObj.getAllCompanies());
   } 
   AddNewCompany(){
     // should pass data to service !
     this.servObj.addACompany(this.newCompany); 
      }
}
