import {HttpClient} from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Post } from './posts.model';
import { Observable } from 'rxjs';

@Injectable({
    providedIn: 'root'
})
export class PostsService {
    allPosts: any = [];
    constructor(public httpClientObj: HttpClient) {
    }
    // Using Observable
//     getAllPosts():Observable<Post[]> {
//         // make an ajax request !
//        return this.httpClientObj.get<Post[]>('https://jsonplaceholder.typicode.com/posts');
// }
// Using Promise
getAllPosts() {
    // make an ajax request !
   return this.httpClientObj.get<Post[]>('https://jsonplaceholder.typicode.com/posts').toPromise();
}
getAPostById(postId:number) {
    // make an ajax request !
   return this.httpClientObj.get<Post>('https://jsonplaceholder.typicode.com/posts/'+postId).toPromise();
}

}
