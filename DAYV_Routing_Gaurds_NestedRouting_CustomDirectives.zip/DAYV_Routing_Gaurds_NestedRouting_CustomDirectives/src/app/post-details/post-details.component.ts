import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { PostsService } from '../posts/posts.service';
import { Post } from '../posts/posts.model';

@Component({
  selector: 'app-post-details',
  templateUrl: './post-details.component.html',
  styleUrls: ['./post-details.component.css']
})
export class PostDetailsComponent implements OnInit {

  thePostId:number;
  thePost:Post = new Post();
  constructor(public currRoute:ActivatedRoute,public postServObj:PostsService) { }
  ngOnInit() {
    this.currRoute.params.subscribe(
      p=>{
        this.thePostId =p.pid;
        let aPromise =this.postServObj.getAPostById(this.thePostId);
        aPromise.then(
          response =>  this.thePost = response
        )
      } 
    )
  }

}
