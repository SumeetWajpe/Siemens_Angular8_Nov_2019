import { ProductModel } from '../product.model';

export class CartItemsService{
    currentItems:ProductModel[] = [];

    addToCart(newItem:ProductModel){
        this.currentItems.push(newItem);
    }

    removeFromCart(itemToBeRemoved){
        let index = this.currentItems.findIndex(i=> i.title == itemToBeRemoved);
        this.currentItems.splice(index,1);
    }
}