import { Component, Input } from "@angular/core";
import { ProductService } from './product.service';
import { ProductModel } from './product.model';
import { CartItemsService } from './cart-items/cartitems.service';


@Component({
    selector:'product',
    templateUrl:'./product.template.html',
   styleUrls:['./product.style.css']
})
export class ProductComponent{
  @Input()  productdetails:ProductModel = new ProductModel();
  isSelected:boolean = false;
  isFree:boolean=false;
  constructor(public prodServObj:ProductService,public cartServObj:CartItemsService){ }
  IncrementLikes(){
      // model changes UI changes(Binding)
      this.productdetails.likes+=1;
  }
  DeleteAProduct(){
      // service ??
      this.prodServObj.deleteAProduct(this.productdetails.title)
  }
  AddToCart(){
      if(!this.isSelected){
        this.cartServObj.addToCart(this.productdetails);
      }else{
          this.cartServObj.removeFromCart(this.productdetails.title)
      }
  }

  ngOnDestroy(){
      console.log('Clean Up..');
  }
}