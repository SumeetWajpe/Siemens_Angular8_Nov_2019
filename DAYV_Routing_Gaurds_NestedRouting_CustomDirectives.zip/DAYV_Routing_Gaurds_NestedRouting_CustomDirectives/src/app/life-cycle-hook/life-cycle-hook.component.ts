import { Component, OnInit, Input } from '@angular/core';

@Component({
  selector: 'app-life-cycle-hook',
  templateUrl: './life-cycle-hook.component.html',
  styleUrls: ['./life-cycle-hook.component.css']
})
export class LifeCycleHookComponent implements OnInit {

 @Input() message:string="";
  constructor() {
    console.log('Within Constructor, Message :' + this.message);
   }
  // called once 
  ngOnInit() {
    console.log('Within ngOnInit, Message :' + this.message);
  }
  ngOnChanges(){
    console.log('Within ngOnChanges, Message :' + this.message);

  }

}
