import { Component, OnInit } from '@angular/core';
import { CompanyService } from './company.service';

@Component({
  selector: 'app-company',
  templateUrl: './company.component.html',
  styleUrls: ['./company.component.css'],
  providers:[CompanyService]
})
export class CompanyComponent  {
 companies:string[] = [];
 newcompany:string="";
  constructor(public compServObj:CompanyService) { 
    this.companies = this.compServObj.getAllCompanies();
  }

  AddNewCompany():void{
      this.compServObj.addnewCompany(this.newcompany);
  }


}
