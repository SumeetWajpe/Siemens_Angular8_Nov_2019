import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import {FormsModule,ReactiveFormsModule} from '@angular/forms';
import {HttpClientModule} from '@angular/common/http';
import {Routes,RouterModule} from '@angular/router';

import { AppComponent } from './app.component';
import {ProductComponent} from './product/product.component';
import { ShoppingCartComponent } from './shopping-cart/shopping-cart.component';
import {QuantityPipe} from './quantity.pipe';
import { CompanyComponent } from './company/company.component';
import { CompanyService } from './company/company.service';
import { ProductService } from './product/product.service';
import { CurrentcartComponent } from './currentcart/currentcart.component';
import { CurrentCartService } from './currentcart/currentcart.service';
import { PostsComponent } from './posts/posts.component';
import { ProductAPIService } from './product/productservicewithhttp';
import { TemplateDrivenComponent } from './template-driven/template-driven.component';
import { ModelDrivenComponent } from './model-driven/model-driven.component';
import { PostDetailsComponent } from './post-details/post-details.component';
import { PostsService } from './posts/posts.service';

var routes:Routes = [
      {path:'',component:ShoppingCartComponent},
      {path:'posts',component:PostsComponent},
      {path:'postdetails/:postid',component:PostDetailsComponent},      
      {path:'company',component:CompanyComponent},
      {path:'**',redirectTo:'/'}
];


@NgModule({
  declarations: [
    AppComponent,ProductComponent, 
    ShoppingCartComponent,QuantityPipe, CompanyComponent, CurrentcartComponent, PostsComponent, TemplateDrivenComponent, ModelDrivenComponent, PostDetailsComponent
  ],
  imports: [
    BrowserModule,FormsModule,
    HttpClientModule,ReactiveFormsModule,
    RouterModule.forRoot(routes)
  ],  
  providers:[CompanyService,ProductService,PostsService,
    CurrentCartService],
  bootstrap: [AppComponent]
})
export class AppModule { }
