import{Component, Input} from '@angular/core';// node_modules
import { Product } from './product.model';
import { ProductService } from './product.service';
import { CurrentCartService } from '../currentcart/currentcart.service';

@Component({
    selector:'product',
    templateUrl:'./product.template.html',
    styleUrls:['./product.style.css']
})
export class ProductComponent{
  @Input()  productdetails:Product={};
  isHighlighted:boolean=false;
  isFree:boolean=false;

  constructor(public prodServObj:ProductService,public currCartServObj:CurrentCartService){}

  ClickHandler(){
      // model update
      this.productdetails.likes++;
  }
  DeleteTheProduct(theId){
    this.prodServObj.deleteAProduct(theId);
  }

  AddToCart(){
    if(this.isHighlighted){
      this.currCartServObj.addItemToCart(this.productdetails);
    }
    else{
      
    }
  }
}