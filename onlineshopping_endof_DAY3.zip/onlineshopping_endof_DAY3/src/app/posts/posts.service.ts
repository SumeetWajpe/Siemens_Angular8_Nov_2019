import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { Post } from './post.model';

@Injectable()
export class PostsService{
    constructor(public httpServObj:HttpClient){

    }

    // Using Observables
    // getAllPosts():Observable<Post[]>{
    //     // make an ajax request
    //   return  this.httpServObj.
    //   get<Post[]>('https://jsonplaceholder.typicode.com/posts');
    // }

    getAllPosts(){
       return this.httpServObj.get<Post[]>('https://jsonplaceholder.typicode.com/posts').toPromise();      
    }
}