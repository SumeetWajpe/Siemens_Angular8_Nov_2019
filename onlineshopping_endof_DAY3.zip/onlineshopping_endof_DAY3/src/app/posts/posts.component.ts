import { Component, OnInit } from '@angular/core';
import { PostsService } from './posts.service';
import { Post } from './post.model';

@Component({
  selector: 'app-posts',
  templateUrl: './posts.component.html',
  styleUrls: ['./posts.component.css'],
  providers: [PostsService]
})
export class PostsComponent implements OnInit {
  posts: Post[] = [];
  constructor(public postServObj: PostsService) {

  }

  ngOnInit() {
    // Using Observables
    // var observable = this.postServObj.getAllPosts();
    // observable.subscribe((response) => {
    //   this.posts = response;
    // });

    // Using Promises
    var thePromise = this.postServObj.getAllPosts();
    thePromise.then(
      (response)=>this.posts = response,
      (err)=>console.log(err)
    );
  }

}
