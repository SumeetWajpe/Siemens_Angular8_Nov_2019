import { Product } from '../product/product.model';

export class CurrentCartService{
    currentItems:Product[] =[];

    addItemToCart(newProduct:Product){        
        this.currentItems.push(newProduct);
    }
}