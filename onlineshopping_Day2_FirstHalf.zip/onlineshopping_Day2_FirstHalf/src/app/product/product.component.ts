import{Component, Input} from '@angular/core';// node_modules
import { Product } from './product.model';

@Component({
    selector:'product',
    templateUrl:'./product.template.html'
})
export class ProductComponent{
  @Input()  productdetails:Product={};

  ClickHandler(){
      // model update
      this.productdetails.likes++;
  }
}